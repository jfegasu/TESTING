/**
 * 
 */
/**
 * @author JOSE F GALINDO
 *
 */
module prueba1 {
}