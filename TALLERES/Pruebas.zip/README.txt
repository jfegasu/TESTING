Para Ejecutar:
java -jar Prueba1.jar
o
Prueba1.bat